(function (app) {
  'use strict';

  app.registerModule('products');
}(ApplicationConfiguration));
