(function (app) {
  'use strict';

  app.registerModule('cms');
}(ApplicationConfiguration));
