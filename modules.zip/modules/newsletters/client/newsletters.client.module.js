(function (app) {
  'use strict';

  app.registerModule('newsletters');
}(ApplicationConfiguration));
