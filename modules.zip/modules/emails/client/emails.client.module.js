(function (app) {
  'use strict';

  app.registerModule('emails');
}(ApplicationConfiguration));
